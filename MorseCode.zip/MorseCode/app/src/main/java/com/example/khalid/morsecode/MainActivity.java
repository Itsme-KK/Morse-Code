package com.example.khalid.morsecode;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.HashMap;

public class MainActivity extends AppCompatActivity {

    Button btn_convert;
    EditText et_msg;
    TextView tv_result;

    HashMap<String, String> hashMap = new HashMap<String, String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });



        hashMap.put("a",".-");
        hashMap.put("A",".-");
        hashMap.put("b","-...");
        hashMap.put("B","-...");
        hashMap.put("c","-.-.");
        hashMap.put("C","-.-.");
        hashMap.put("d","-..");
        hashMap.put("D","-..");
        hashMap.put("e",".");
        hashMap.put("E",".");
        hashMap.put("f","..-.");
        hashMap.put("F","..-.");
        hashMap.put("g","--.");
        hashMap.put("G","--.");
        hashMap.put("h","....");
        hashMap.put("H","....");
        hashMap.put("i","..");
        hashMap.put("I","..");
        hashMap.put("j",".---");
        hashMap.put("J",".---");
        hashMap.put("k","-.-");
        hashMap.put("K","-.-");
        hashMap.put("l",".-..");
        hashMap.put("L",".-..");
        hashMap.put("m","--");
        hashMap.put("M","--");
        hashMap.put("n","-.");
        hashMap.put("N","-.");
        hashMap.put("o","---");
        hashMap.put("O","---");
        hashMap.put("p",".--.");
        hashMap.put("P",".--.");
        hashMap.put("q","--.-");
        hashMap.put("Q","--.-");
        hashMap.put("r",".-.");
        hashMap.put("R",".-.");
        hashMap.put("s","...");
        hashMap.put("S","...");
        hashMap.put("t","-");
        hashMap.put("T","-");
        hashMap.put("u","..-");
        hashMap.put("U","..-");
        hashMap.put("v","...-");
        hashMap.put("V","...-");
        hashMap.put("w",".--");
        hashMap.put("W",".--");
        hashMap.put("x","-..-");
        hashMap.put("X","-..-");
        hashMap.put("y","-.--");
        hashMap.put("Y","-.--");
        hashMap.put("z","--..");
        hashMap.put("Z","--..");
        hashMap.put("0","-----");
        hashMap.put("1",".----");
        hashMap.put("2","..---");
        hashMap.put("3","...--");
        hashMap.put("4","....-");
        hashMap.put("5",".....");
        hashMap.put("6","-....");
        hashMap.put("7","--...");
        hashMap.put("8","---..");
        hashMap.put("9","----.");
        hashMap.put("\\","----..");
        hashMap.put("/","....--");
        hashMap.put("[",".--...");
        hashMap.put("]","-..---");
        hashMap.put("<","--..--");
        hashMap.put(">","..--..");
        hashMap.put("(","---...");
        hashMap.put(")","...---");
        hashMap.put("{","--..-");
        hashMap.put("}","..--.");
        hashMap.put(".",".-----");
        hashMap.put(",","-.....");
        hashMap.put("_","----.-");
        hashMap.put("|","....-.");
        hashMap.put("?","-.----");
        hashMap.put("!",".-....");
        hashMap.put(";","-....-");
        hashMap.put(":",".----.");
        hashMap.put("-",".---.");
        hashMap.put("$","..----");
        hashMap.put("%","...-.-");
        hashMap.put("\"","...--.");
        hashMap.put("@","---..-");
        hashMap.put("'","..-...");
        hashMap.put("`","--.---");
        hashMap.put("^","-...--");
        hashMap.put("~","---.--");
        hashMap.put("#","..---.");
        hashMap.put("&",".---..");
        hashMap.put("+","-...-");
        hashMap.put("=","---.-");
        hashMap.put("*","-..--");

        btn_convert = findViewById(R.id.btn_convert);
        et_msg = findViewById(R.id.et_msg);
        tv_result = findViewById(R.id.tv_result);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    public void convert(View view){
        String msg = et_msg.getText().toString();
        String msg1[] = msg.split("");
        tv_result.setText("");
        for(int i=0 ; i<msg1.length ; i++){
            String result = hashMap.get(msg1[i]);
            if(result == null){
                tv_result.setText(tv_result.getText() + "/ ");
            } else{
                tv_result.setText(tv_result.getText() + result + " ");
            }
        }
    }
}
//tv_result.setText(tv_result.getText() + result + " ");
//tv_result.setText(tv_result.getText() + StringData.get(i) + " ");